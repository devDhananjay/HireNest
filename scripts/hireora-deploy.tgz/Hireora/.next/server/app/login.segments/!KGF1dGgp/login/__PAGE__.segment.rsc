1:"$Sreact.fragment"
2:"/_next/static/chunks/3rn7dw6x_wvjn.js"
3:"/_next/static/chunks/1_2pqpc3o5k2x.js"
4:"/_next/static/chunks/1b9a3j7w6ubgx.js"
5:"/_next/static/chunks/3790syboxwb6y.js"
6:"/_next/static/chunks/12_erohqrhp3x.js"
7:I[85266,["$2","$3","$4","$5","$6"],"Providers"]
8:I[39756,["$2","$3","$4","$5","$6"],"default"]
9:I[37457,["$2","$3","$4","$5","$6"],"default"]
a:"/_next/static/chunks/3zt_16xndew4w.js"
b:I[5014,["$2","$3","$4","$5","$6","$a"],"default"]
c:I[22016,["$2","$3","$4","$5","$6","$a"],""]
1c:"ViewportBoundary"
1d:I[97367,["$2","$3","$4","$5","$6"],"$1c"]
1e:"MetadataBoundary"
1f:I[97367,["$2","$3","$4","$5","$6"],"$1e"]
20:"$Sreact.suspense"
21:I[27201,["$2","$3","$4","$5","$6"],"IconMark"]
:HL["/_next/static/chunks/03rl7qr_jtezb.css","style"]
:HL["/_next/static/chunks/0fi0l1hmf12oa.css","style"]
e:X
18:X
18:C
19:[["children",{"s":"__PAGE__","h":160,"d":{"r":"$L1a","p":"$@1b","v":null,"s":"$e"}}]]
15:[["children",{"s":"login","h":96,"d":{"r":"$L16","p":"$@17","v":"$18","s":"$e"},"c":"$Q19"}]]
f:[["children",{"s":"(auth)","h":96,"d":{"r":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/3zt_16xndew4w.js","async":true}]],["$","div",null,{"className":"grid min-h-screen bg-[#f3f4f8] lg:grid-cols-2","children":[["$","div",null,{"className":"mesh-dark relative hidden overflow-hidden p-10 text-white lg:flex lg:flex-col","children":[["$","$Lc",null,{"href":"/","className":"group flex min-w-0 items-center gap-2 sm:gap-2.5","children":[["$","span",null,{"className":"relative flex size-9 shrink-0 items-center justify-center rounded-full text-[14px] font-bold tracking-tight transition-transform duration-300 group-hover:scale-[1.04] sm:size-10 sm:text-[15px] bg-white text-black shadow-[0_10px_28px_rgba(0,0,0,0.22)]","children":"H"}],["$","span",null,{"className":"font-heading truncate text-[1.05rem] font-semibold tracking-[-0.045em] sm:text-[1.2rem] text-white","children":"HIREORA"}]]}],["$","div",null,{"className":"pointer-events-none absolute -right-16 -bottom-24 font-heading text-[18rem] leading-none font-semibold text-white/[0.04]","children":"H"}],["$","div",null,{"className":"mt-auto max-w-md pb-10","children":[["$","p",null,{"className":"text-[12px] font-medium tracking-[0.18em] text-white/45 uppercase","children":"HIREORA"}],["$","h1",null,{"className":"mt-3 font-heading text-5xl leading-[1.08] font-semibold","children":"Connecting talent. Creating possibilities."}],["$","p",null,{"className":"mt-5 text-sm leading-7 text-white/65","children":["Connecting Talent. Creating Possibilities."," Demo access is role-based and uses sample Indian-market data."]}]]}]]}],["$","div",null,{"className":"flex items-center justify-center p-6","children":["$","div",null,{"className":"w-full max-w-md rounded-[2rem] bg-white p-8 shadow-soft sm:p-10","children":["$","$L8",null,{"parallelRouterKey":"children","template":["$","$L9",null,{}],"notFound":[["$","div",null,{"className":"container-shell py-24 text-center","children":[["$","div",null,{"className":"flex justify-center","children":["$","span",null,{"className":"inline-flex shrink-0 items-center justify-center rounded-full size-11 bg-[#f4f5f8] text-foreground","children":"$L10"}]}],"$L11","$L12","$L13"]}],[]]}]}]}]]}]]}],"p":"$@14","v":null,"s":"$e"},"c":"$Q15"}]]
0:{"t":{"t":{"s":"","h":80,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/03rl7qr_jtezb.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/0fi0l1hmf12oa.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/3rn7dw6x_wvjn.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/1_2pqpc3o5k2x.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/1b9a3j7w6ubgx.js","async":true}],["$","script","script-3",{"src":"/_next/static/chunks/3790syboxwb6y.js","async":true}],["$","script","script-4",{"src":"/_next/static/chunks/12_erohqrhp3x.js","async":true}]],["$","html",null,{"lang":"en","data-scroll-behavior":"smooth","className":"wRojWG_variable _4VqPoG_variable h-full","children":["$","body",null,{"className":"min-h-full bg-offwhite font-sans text-charcoal antialiased","children":["$","$L7",null,{"children":["$","$L8",null,{"parallelRouterKey":"children","template":["$","$L9",null,{}],"notFound":[["$","div",null,{"className":"container-shell py-24 text-center","children":[["$","div",null,{"className":"flex justify-center","children":["$","span",null,{"className":"inline-flex shrink-0 items-center justify-center rounded-full size-11 bg-[#f4f5f8] text-foreground","children":["$","$Lb",null,{"icon":{"name":"search","size":24,"node":[["path",{"d":"m21 21-4.34-4.34","key":"14j7rj"}],["circle",{"cx":"11","cy":"11","r":"8","key":"4ej97u"}]]},"className":"size-4"}]}]}],["$","h1",null,{"className":"mt-6 font-heading text-4xl font-semibold","children":"Page not found"}],["$","p",null,{"className":"mt-3 text-muted-foreground","children":"That route is not part of the HIREORA workspace."}],["$","$Lc",null,{"href":"/","className":"inline-flex h-12 items-center justify-center rounded-full bg-black px-6 text-sm font-medium text-white shadow-[0_10px_24px_rgba(17,17,17,0.16)] transition duration-300 hover:-translate-y-px hover:bg-[#1d1d1d] mt-8","children":"Back home"}]]}],[]]}]}]}]}]]}],"p":"$@d","v":null,"s":"$e"},"c":"$Qf"},"h":{"r":["$","$1","h",{"children":[null,["$","$L1d",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L1f",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$20",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"HIREORA — Connecting Talent. Creating Possibilities."}],["$","meta","1",{"name":"description","content":"HIREORA is a premium recruitment and placement platform connecting candidates, employers and specialist recruiters across India."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L21","3",{}]]}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":"$@22","v":null,"s":"$e"}},"a":"$@23","u":"$@24","b":"wQvjGnLZEUAeGsZxVuvIq"}
25:I[47257,["$2","$3","$4","$5","$6"],"ClientPageRoot"]
26:"/_next/static/chunks/1pubwcw4i-qdv.js"
27:I[388,["$2","$3","$4","$5","$6","$a","$26"],"default"]
2a:I[97367,["$2","$3","$4","$5","$6"],"OutletBoundary"]
10:["$","$Lb",null,{"icon":"$0:t:t:d:r:props:children:1:props:children:props:children:props:children:props:notFound:0:props:children:0:props:children:props:children:props:icon","className":"size-4"}]
11:["$","h1",null,{"className":"mt-6 font-heading text-4xl font-semibold","children":"Page not found"}]
12:["$","p",null,{"className":"mt-3 text-muted-foreground","children":"That route is not part of the HIREORA workspace."}]
13:["$","$Lc",null,{"href":"/","className":"inline-flex h-12 items-center justify-center rounded-full bg-black px-6 text-sm font-medium text-white shadow-[0_10px_24px_rgba(17,17,17,0.16)] transition duration-300 hover:-translate-y-px hover:bg-[#1d1d1d] mt-8","children":"Back home"}]
16:["$","$1","c",{"children":[null,["$","$L8",null,{"parallelRouterKey":"children","template":["$","$L9",null,{}]}]]}]
1a:["$","$1","c",{"children":[["$","$L25",null,{"Component":"$27","serverProvidedParams":{"searchParams":{},"params":{},"promises":["$@28","$@29"]}}],[["$","script","script-0",{"src":"/_next/static/chunks/1pubwcw4i-qdv.js","async":true}]],["$","$L2a",null,{"children":["$","$20",null,{"name":"Next.MetadataOutlet","children":"$@2b"}]}]]}]
e:300
28:{}
29:"$1a:props:children:0:props:serverProvidedParams:params"
2b:null
24:true
e:C
23:0
17:"$undefined"
14:"$undefined"
d:"$undefined"
22:"$undefined"
1b:"$undefined"
