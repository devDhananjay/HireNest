1:"$Sreact.fragment"
2:"/_next/static/chunks/3rn7dw6x_wvjn.js"
3:"/_next/static/chunks/1_2pqpc3o5k2x.js"
4:"/_next/static/chunks/1b9a3j7w6ubgx.js"
5:"/_next/static/chunks/3790syboxwb6y.js"
6:"/_next/static/chunks/12_erohqrhp3x.js"
7:I[85266,["$2","$3","$4","$5","$6"],"Providers"]
8:I[39756,["$2","$3","$4","$5","$6"],"default"]
9:I[37457,["$2","$3","$4","$5","$6"],"default"]
a:"/_next/static/chunks/3zt_16xndew4w.js"
b:I[5014,["$2","$3","$4","$5","$6","$a"],"default"]
c:I[22016,["$2","$3","$4","$5","$6","$a"],""]
e:"/_next/static/chunks/3_ftdz07hoc4q.js"
f:"/_next/static/chunks/2voj3ymbl4caa.js"
10:I[90414,["$2","$3","$4","$5","$6","$e","$f"],"DashboardShell"]
13:I[97367,["$2","$3","$4","$5","$6"],"OutletBoundary"]
14:"$Sreact.suspense"
16:"ViewportBoundary"
17:I[97367,["$2","$3","$4","$5","$6"],"$16"]
19:"MetadataBoundary"
1a:I[97367,["$2","$3","$4","$5","$6"],"$19"]
1c:I[68027,["$2","$3","$4","$5","$6"],"default",1]
:HL["/_next/static/chunks/03rl7qr_jtezb.css","style"]
:HL["/_next/static/chunks/0fi0l1hmf12oa.css","style"]
:HL["/_next/static/media/c0680f1bdb3a2e90-s.p.1gsd1jahc5dg_.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/d8aeca813a9ab546-s.p.18rizl4rsrl42.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
11:[["children",{"s":"__PAGE__","h":512,"d":{"r":["$","$1","c",{"children":["$L12",null,["$","$L13",null,{"children":["$","$14",null,{"name":"Next.MetadataOutlet","children":"$@15"}]}]]}],"p":false,"v":null}}]]
d:[["children",{"s":"admin","h":512,"d":{"r":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/3_ftdz07hoc4q.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/2voj3ymbl4caa.js","async":true,"nonce":"$undefined"}]],["$","$L10",null,{"role":"admin","children":["$","$L8",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L9",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]}]]}],"p":false,"v":null},"c":"$Q11"}]]
0:{"P":null,"c":["","admin"],"q":"","i":false,"t":{"t":{"s":"","h":528,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/03rl7qr_jtezb.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/0fi0l1hmf12oa.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/3rn7dw6x_wvjn.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/1_2pqpc3o5k2x.js","async":true,"nonce":"$undefined"}],["$","script","script-2",{"src":"/_next/static/chunks/1b9a3j7w6ubgx.js","async":true,"nonce":"$undefined"}],["$","script","script-3",{"src":"/_next/static/chunks/3790syboxwb6y.js","async":true,"nonce":"$undefined"}],["$","script","script-4",{"src":"/_next/static/chunks/12_erohqrhp3x.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","data-scroll-behavior":"smooth","className":"wRojWG_variable _4VqPoG_variable h-full","children":["$","body",null,{"className":"min-h-full bg-offwhite font-sans text-charcoal antialiased","children":["$","$L7",null,{"children":["$","$L8",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L9",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"className":"container-shell py-24 text-center","children":[["$","div",null,{"className":"flex justify-center","children":["$","span",null,{"className":"inline-flex shrink-0 items-center justify-center rounded-full size-11 bg-[#f4f5f8] text-foreground","children":["$","$Lb",null,{"ref":"$undefined","icon":{"name":"search","size":24,"node":[["path",{"d":"m21 21-4.34-4.34","key":"14j7rj"}],["circle",{"cx":"11","cy":"11","r":"8","key":"4ej97u"}]]},"className":"size-4"}]}]}],["$","h1",null,{"className":"mt-6 font-heading text-4xl font-semibold","children":"Page not found"}],["$","p",null,{"className":"mt-3 text-muted-foreground","children":"That route is not part of the HIREORA workspace."}],["$","$Lc",null,{"href":"/","className":"inline-flex h-12 items-center justify-center rounded-full bg-black px-6 text-sm font-medium text-white shadow-[0_10px_24px_rgba(17,17,17,0.16)] transition duration-300 hover:-translate-y-px hover:bg-[#1d1d1d] mt-8","children":"Back home"}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]}]]}],"p":false,"v":null},"c":"$Qd"},"h":{"r":["$","$1","h",{"children":[null,["$","$L17",null,{"children":"$L18"}],["$","$L1a",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$14",null,{"name":"Next.Metadata","children":"$L1b"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":false,"v":null}},"m":"$undefined","G":["$1c",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/03rl7qr_jtezb.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/0fi0l1hmf12oa.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"wQvjGnLZEUAeGsZxVuvIq"}
12:E{"digest":"NEXT_REDIRECT;replace;/admin/dashboard;307;"}
18:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
1d:I[27201,["$2","$3","$4","$5","$6"],"IconMark"]
15:null
1b:[["$","title","0",{"children":"HIREORA — Connecting Talent. Creating Possibilities."}],["$","meta","1",{"name":"description","content":"HIREORA is a premium recruitment and placement platform connecting candidates, employers and specialist recruiters across India."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L1d","3",{}]]
