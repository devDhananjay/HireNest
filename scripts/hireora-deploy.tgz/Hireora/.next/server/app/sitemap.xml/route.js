var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/node_modules_next_dist_16uekqf-emgzs._.js")
R.c("server/chunks/_0muyrbf1n2d7d._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/src_lib_demo_seed_ts_0ge5gop3srmeu._.js")
R.c("server/chunks/_next-internal_server_app_sitemap_xml_route_actions_05l5km9x9dlo2.js")
R.m(83345)
module.exports=R.m(83345).exports
