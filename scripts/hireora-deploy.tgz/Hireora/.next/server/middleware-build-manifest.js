globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/wQvjGnLZEUAeGsZxVuvIq/_buildManifest.js",
    "static/wQvjGnLZEUAeGsZxVuvIq/_ssgManifest.js",
    "static/wQvjGnLZEUAeGsZxVuvIq/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3be5ypa669k_3.js",
    "static/chunks/2rv5jvl35qh22.js",
    "static/chunks/2vf_1gqzqkc_n.js",
    "static/chunks/3j-q-52j3gc31.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/forgot-password/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/login/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/register/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/about/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/career-resources/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/career-resources/[slug]/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/companies/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/contact/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/for-candidates/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/for-employers/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/jobs/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/jobs/[slug]/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/privacy-policy/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/recruitment-services/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/services/bulk-hiring/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/services/executive-search/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/services/permanent-staffing/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/terms/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/applications/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/companies/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/dashboard/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/jobs/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/recruiters/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/reports/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/settings/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/users/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/candidate/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/candidate/applications/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/candidate/dashboard/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/candidate/interviews/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/candidate/jobs/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/candidate/profile/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/candidate/saved-jobs/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/employer/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/employer/applications/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/employer/candidates/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/employer/company-profile/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/employer/dashboard/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/employer/jobs/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/employer/jobs/create/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/recruiter/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/recruiter/candidates/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/recruiter/clients/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/recruiter/dashboard/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/recruiter/interviews/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/recruiter/jobs/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/recruiter/pipeline/page": {
      "otherChunks": [
        "static/chunks/3be5ypa669k_3.js",
        "static/chunks/2rv5jvl35qh22.js",
        "static/chunks/2vf_1gqzqkc_n.js",
        "static/chunks/3j-q-52j3gc31.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
