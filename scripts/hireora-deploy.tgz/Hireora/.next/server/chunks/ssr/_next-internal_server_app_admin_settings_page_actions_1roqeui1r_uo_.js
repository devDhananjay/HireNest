module.exports=[78577,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_settings_page_actions_1roqeui1r_uo_.js.map