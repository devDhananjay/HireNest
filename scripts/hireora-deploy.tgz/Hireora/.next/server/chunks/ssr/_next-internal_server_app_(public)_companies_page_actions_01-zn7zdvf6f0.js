module.exports=[61875,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_companies_page_actions_01-zn7zdvf6f0.js.map