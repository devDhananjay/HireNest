module.exports=[65547,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_candidate_saved-jobs_page_actions_0mpripz86va37.js.map