module.exports=[85500,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_career-resources_page_actions_1eov_pswix6-a.js.map