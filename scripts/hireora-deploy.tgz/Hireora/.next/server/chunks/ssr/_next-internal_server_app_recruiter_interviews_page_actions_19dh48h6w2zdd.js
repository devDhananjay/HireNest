module.exports=[24505,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_recruiter_interviews_page_actions_19dh48h6w2zdd.js.map