module.exports=[81153,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_recruiters_page_actions_1u3wzs8-g-bdu.js.map