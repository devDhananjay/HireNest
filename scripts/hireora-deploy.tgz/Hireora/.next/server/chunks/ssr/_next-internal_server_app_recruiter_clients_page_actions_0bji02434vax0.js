module.exports=[10489,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_recruiter_clients_page_actions_0bji02434vax0.js.map