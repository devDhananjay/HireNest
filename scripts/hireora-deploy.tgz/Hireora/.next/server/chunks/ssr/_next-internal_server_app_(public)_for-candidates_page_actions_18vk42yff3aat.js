module.exports=[87378,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_for-candidates_page_actions_18vk42yff3aat.js.map