module.exports=[91940,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_candidate_jobs_page_actions_1j3q97gk0somi.js.map