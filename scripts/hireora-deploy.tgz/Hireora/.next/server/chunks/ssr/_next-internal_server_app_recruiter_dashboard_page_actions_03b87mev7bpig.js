module.exports=[77802,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_recruiter_dashboard_page_actions_03b87mev7bpig.js.map