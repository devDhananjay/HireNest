module.exports=[41678,a=>{"use strict";var b=a.i(7997),c=a.i(717);a.s(["default",0,function({children:a}){return(0,b.jsx)(c.Suspense,{fallback:(0,b.jsx)("div",{className:"container-shell py-20",children:"Loading jobs…"}),children:a})}])},87667,function(a){a.n(a.i(41678))}];

//# sourceMappingURL=src_app_%28public%29_jobs_layout_tsx_1w2ylac3z1wko._.js.map