module.exports=[10088,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_employer_candidates_page_actions_1tox8xi7q8cer.js.map